//
//  ViewController.swift
//  PR17
//
//  Created by Дмитрий Лазарев on 03/06/2021.
//  Copyright © 2021 Дмитрий Лазарев. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var nextbtn: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

}

